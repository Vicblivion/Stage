var http=require('http'),
	fs=require('fs'),

//Création du serveur node.js et envoi de la page du lecteur en
//cas de connexion direct par IP.
var server=http.createServer(function(req,res){
  fs.readFile('./index.html', 'utf-8',function(error,content){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.end(content);
  });
});

var io=require('socket.io').listen(server);

//Renvoi à tous les autres clients d'un message émit par un client.
io.sockets.on('connection',function(socket){
	socket.on('message',function(message){
		socket.broadcast.emit('message',{message:message});
	});
});

//Communication sur le port 8080, modifiable mais doit être changé
//également dans index.html
server.listen(8080);