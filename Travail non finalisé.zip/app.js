var http=require('http'),
	fs=require('fs'),
	reader=require('filereader');
	file=require('file');
	slice=require('w3c-blob');

var server=http.createServer(function(req,res){
  fs.readFile('./index.html', 'utf-8',function(error,content){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.end(content);
  });
	socket.broadcast.emit('stream',reader);
});

var io=require('socket.io').listen(server);

//var reader=new FileReader(),
	//file=new File('./test.txt'),
	var section=2048,
	depart=0;
	
function lecture(file,depart,slice,reader){
	//Vérifie si le fichier a été ntièrement lu ou non.
	if(file.slice(depart).size()!=0){
		//Vérifie si la zone du fichier à lire est plus petite que taille d'une section.
		if(file.slice(depart).size()<=section){
			slice=file.slice(depart);
		}
		else{
			slice=file.slice(depart,depart+section);
		}
		//Lecture de la section
		reader=readAsText(slice);
		//Lecture terminée avec succès
		reader.addEventListener('load', function() {
			//Emission de la section
			socket.broadcast.emit('stream',reader.result);
			//Déplacement au début de la section suivante
			depart+=section;
			Lecture(file,depart,slice,reader);
		});
		//Lecture interrompue
		reader.addEventListener('abort', function() {
			Lecture(file,depart,slice,reader);
		});
		//Erreur lors de la lecture
		reader.addEventListener('error', function() {
			Lecture(file,depart,slice,reader);
		});
	}
};

io.sockets.on('connection',function(socket){
	lecture(file,depart,slice,reader);
	socket.on('message',function(message){
		socket.broadcast.emit('message',{message:message});
	});
});

server.listen(8080);