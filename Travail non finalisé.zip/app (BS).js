//NOM DE DOMAINE BINARYJS EXPIRE, INUTILISABLE EN ATTENDANT UN RETOUR A LA NORMALE
var http=require('http'),
	fs=require('fs'),
	BS=require('binaryjs').BinaryServer;

var server=http.createServer(function(req,res){
  fs.readFile('./index.html', 'utf-8',function(error,content){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.end(content);
  });
});

var io=require('socket.io').listen(server);

io.sockets.on('connection',function(socket){
	socket.on('message',function(message){
		socket.broadcast.emit('message',{message:message});
	});
});

var bs = new BS({server: server, path: './binary-endpoint'});

bs.on('connection', function(client){
  var file = fs.createReadStream(__dirname +'./Diapo.jpg');
  client.send(file);
});

server.listen(8080);